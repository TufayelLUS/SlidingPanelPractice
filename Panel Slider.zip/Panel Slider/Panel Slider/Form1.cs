﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Panel_Slider
{
    public partial class Form1 : Form
    {
        bool sliderOn = false;
        public Form1()
        {
            InitializeComponent();
            slider.Width = 0;
            btnSlider.Left = 0;
            sliderTitle.Left = 75;
            slideBtn1.Width = 0;
            slideBtn2.Width = 0;
            slideBtn3.Width = 0;
            slidermen.Visible = false;
        }

        private void btnSlider_Click(object sender, EventArgs e)
        {
            if(sliderOn == true)
            {
                sliderOn = false;
                //slider.Width = 0;
                //btnSlider.Left = 0;
                while(slider.Width > 0)
                {
                    slider.Width--;
                    btnSlider.Left--;
                    sliderTitle.Left--;
                    slideBtn1.Width--;
                    slideBtn2.Width--;
                    slideBtn3.Width--;
                }
                slidermen.Visible = false;
                btnSlider.Text = ">>";
            }
            else
            {
                sliderOn = true;
                //slider.Width = 199;
                //btnSlider.Left = 199;
                while (slider.Width < 199)
                {
                    slider.Width++;
                    btnSlider.Left++;
                    sliderTitle.Left++;
                    slideBtn1.Width++;
                    slideBtn2.Width++;
                    slideBtn3.Width++;
                }
                slidermen.Visible = true;
                btnSlider.Text = "<<";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
