﻿namespace Panel_Slider
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSlider = new System.Windows.Forms.Button();
            this.slider = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sliderTitle = new System.Windows.Forms.Label();
            this.slideBtn1 = new System.Windows.Forms.Button();
            this.slideBtn2 = new System.Windows.Forms.Button();
            this.slideBtn3 = new System.Windows.Forms.Button();
            this.slidermen = new System.Windows.Forms.Label();
            this.slider.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSlider
            // 
            this.btnSlider.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSlider.FlatAppearance.BorderSize = 0;
            this.btnSlider.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSlider.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSlider.ForeColor = System.Drawing.Color.White;
            this.btnSlider.Location = new System.Drawing.Point(199, 0);
            this.btnSlider.Name = "btnSlider";
            this.btnSlider.Size = new System.Drawing.Size(75, 56);
            this.btnSlider.TabIndex = 0;
            this.btnSlider.Text = ">>";
            this.btnSlider.UseVisualStyleBackColor = false;
            this.btnSlider.Click += new System.EventHandler(this.btnSlider_Click);
            // 
            // slider
            // 
            this.slider.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.slider.Controls.Add(this.slidermen);
            this.slider.Controls.Add(this.slideBtn3);
            this.slider.Controls.Add(this.slideBtn2);
            this.slider.Controls.Add(this.slideBtn1);
            this.slider.Location = new System.Drawing.Point(0, 0);
            this.slider.Name = "slider";
            this.slider.Size = new System.Drawing.Size(199, 451);
            this.slider.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(758, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 28);
            this.button1.TabIndex = 2;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Navy;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(665, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 28);
            this.button2.TabIndex = 3;
            this.button2.Text = "_";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.sliderTitle);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 40);
            this.panel1.TabIndex = 4;
            // 
            // sliderTitle
            // 
            this.sliderTitle.AutoSize = true;
            this.sliderTitle.Font = new System.Drawing.Font("Century Gothic", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sliderTitle.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.sliderTitle.Location = new System.Drawing.Point(276, 8);
            this.sliderTitle.Name = "sliderTitle";
            this.sliderTitle.Size = new System.Drawing.Size(295, 25);
            this.sliderTitle.TabIndex = 5;
            this.sliderTitle.Text = "UI design with Menu Drawer";
            // 
            // slideBtn1
            // 
            this.slideBtn1.BackColor = System.Drawing.Color.Navy;
            this.slideBtn1.FlatAppearance.BorderSize = 0;
            this.slideBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slideBtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slideBtn1.ForeColor = System.Drawing.Color.White;
            this.slideBtn1.Location = new System.Drawing.Point(0, 129);
            this.slideBtn1.Name = "slideBtn1";
            this.slideBtn1.Size = new System.Drawing.Size(199, 53);
            this.slideBtn1.TabIndex = 5;
            this.slideBtn1.Text = "Menu 1";
            this.slideBtn1.UseVisualStyleBackColor = false;
            this.slideBtn1.Click += new System.EventHandler(this.button3_Click);
            // 
            // slideBtn2
            // 
            this.slideBtn2.BackColor = System.Drawing.Color.Navy;
            this.slideBtn2.FlatAppearance.BorderSize = 0;
            this.slideBtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slideBtn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slideBtn2.ForeColor = System.Drawing.Color.White;
            this.slideBtn2.Location = new System.Drawing.Point(0, 186);
            this.slideBtn2.Name = "slideBtn2";
            this.slideBtn2.Size = new System.Drawing.Size(199, 53);
            this.slideBtn2.TabIndex = 6;
            this.slideBtn2.Text = "Menu 2";
            this.slideBtn2.UseVisualStyleBackColor = false;
            // 
            // slideBtn3
            // 
            this.slideBtn3.BackColor = System.Drawing.Color.Navy;
            this.slideBtn3.FlatAppearance.BorderSize = 0;
            this.slideBtn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slideBtn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slideBtn3.ForeColor = System.Drawing.Color.White;
            this.slideBtn3.Location = new System.Drawing.Point(0, 243);
            this.slideBtn3.Name = "slideBtn3";
            this.slideBtn3.Size = new System.Drawing.Size(199, 53);
            this.slideBtn3.TabIndex = 7;
            this.slideBtn3.Text = "Menu 3";
            this.slideBtn3.UseVisualStyleBackColor = false;
            // 
            // slidermen
            // 
            this.slidermen.AutoSize = true;
            this.slidermen.Font = new System.Drawing.Font("Century Gothic", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slidermen.ForeColor = System.Drawing.Color.White;
            this.slidermen.Location = new System.Drawing.Point(33, 57);
            this.slidermen.Name = "slidermen";
            this.slidermen.Size = new System.Drawing.Size(131, 25);
            this.slidermen.TabIndex = 6;
            this.slidermen.Text = "Slider Menu";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(857, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.slider);
            this.Controls.Add(this.btnSlider);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.slider.ResumeLayout(false);
            this.slider.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSlider;
        private System.Windows.Forms.Panel slider;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label sliderTitle;
        private System.Windows.Forms.Button slideBtn1;
        private System.Windows.Forms.Button slideBtn3;
        private System.Windows.Forms.Button slideBtn2;
        private System.Windows.Forms.Label slidermen;
    }
}

